package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Fab;

@Controller
public class FabController {

	@RequestMapping("fab")
	public ModelAndView fload()
	{
		return new ModelAndView("fab","command",new Fab());
	}
	@RequestMapping("fablogic")
	
	public ModelAndView fabLogic(@ModelAttribute("SpringMvcExampleMain")Fab f, ModelMap model)
	{
		String  result  = "";
		int i, a=-1,b=1,c=0;
		
		for(i=1;i<f.getNum();i++)
		{
			c=a+b;
			result  = result +c+" ";
			a=b;
			b=c;
			
		}
		ModelAndView obj = new ModelAndView("fab","command",new Fab());
		obj.addObject("res", "Result is"+result);
	    return obj ;
	    
	}
}
