package controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Admin;

@Controller
public class LoginController 
{
@RequestMapping("login")
public ModelAndView loginDemo(@ModelAttribute("SpringMvcExampleMain")Admin s, ModelMap mp)
{
	
	
	return new ModelAndView("login","command",new Admin());
}
@RequestMapping("logincode")
public ModelAndView loginCodeDemo(@ModelAttribute("SpringMvcExampleMain")Admin s, ModelMap mp, HttpServletRequest request,HttpServletResponse response)
{
	
	    HttpSession session = request.getSession();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Query q = ses.createQuery("from Admin e where e.username=? and e.password=?");
		q.setString(0,s.getUsername());
		q.setString(1,s.getPassword());
		List lst = q.list();
		if(lst.size()>0)
		{
			Cookie c = new Cookie("cuser",s.getUsername());
			c.setMaxAge(1000000);
			response.addCookie(c);
			session.setAttribute("uid",s.getUsername());
			return new ModelAndView("redirect:showfeed.do");
		}
		else
		{
			mp.addAttribute("key","invalid userid and password");
			return new ModelAndView("login","command",new Admin());
			
		}

	
	
}
}
