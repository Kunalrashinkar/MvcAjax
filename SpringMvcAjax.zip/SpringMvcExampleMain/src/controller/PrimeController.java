package controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PrimeController {
	
	@RequestMapping("primepath")
	public String primeLoad()
	{
		return "primeview";
	}
	
	@RequestMapping("primelogic")
	public ModelAndView primeLogic(HttpServletRequest request)
	{
		int num = Integer.parseInt(request.getParameter("txtnum"));
		String s = "";
		int i;
		for(i=2;i<num;i++)
		{
			if(num%i==0)
			{
				s = "Not Prime";
				break;
			}
		}
		if(num==i)
		{
			s="prime";
		}
		return new ModelAndView("primeview","key",s);
	}

}
