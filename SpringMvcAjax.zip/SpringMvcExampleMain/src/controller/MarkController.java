package controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MarkController {
	
	@RequestMapping("markpath")
	public String marksheet()
	{
		return "marksheetview";
	}
	 
	@RequestMapping("markLogic")
	public ModelAndView marklogic(HttpServletRequest request)
	{
		int a = Integer.parseInt(request.getParameter("txtnum1"));
		int b = Integer.parseInt(request.getParameter("txtnum2"));
		int c = Integer.parseInt(request.getParameter("txtnum3"));
		int d = Integer.parseInt(request.getParameter("txtnum4"));
		int e = Integer.parseInt(request.getParameter("txtnum5"));
		
		int per = (a+b+c+d+e)/5;
		return new ModelAndView("marksheetview","per","percentage is "+per);
	}

}
